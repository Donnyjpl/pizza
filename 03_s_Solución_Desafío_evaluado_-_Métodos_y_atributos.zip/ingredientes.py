vegetales = ["aceitunas", "tomate", "champiñones"]
proteicos = ["vacuno", "pollo", "carne vegetal"]
masas = ["tradicional", "delgada"]