from pizza import Pizza

# 5.a
print("\nAtributos de clase")
print("==================\n")
print(f"Precio : {Pizza.precio}")
print(f"Tamaño : {Pizza.tamaño}")
print(f"Ingredientes: {Pizza.num_ingredientes}")

# 5.b
salsas = ['salsa de tomate', 'salsa bbq']

print("\nProbando validar_componente()")
print("=============================\n")
print(Pizza.validar_componente('salsa de tomate', salsas))

# 5.c
# Instanciando objeto de tipo Pizza --> __init__()
pedido = Pizza()

print("\nAtributos de instancia valores x defecto")
print("========================================\n")
print(f"Atributos : {pedido.__dict__}")

pedido.realizar_pedido()

# 5.d
print(f"\nAtributos : {str(pedido.__dict__)[1:-1]}")

# 5.e
try:
    print(Pizza.pizza_valida)
except AttributeError:
    print("\nAttributeError: Pizza.pizza_valida")
    print("==================================\n")
    print("Type object 'Pizza' has no attribute 'pizza_valida'")