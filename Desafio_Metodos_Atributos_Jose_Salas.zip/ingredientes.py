''' listado de ingredientes o componentes de la pizza'''

ingredientes_proteicos = ['pollo', 'vacuno', 'carne vegetal']

ingredientes_vegetales = ['tomate','aceitunas', 'champiñones']

masas = ['tradicional', 'delgada']