from ingredientes import *

class Pizza():
    precio = 10_000
    tamaño = 'familiar'
    num_ingredientes = 3
    
    # Constructor
    def __init__(self, ingredientes = [], masa = None):
        self.ingredientes = ingredientes
        self.masa = masa
        self.pizza_valida = self.validar_pizza()

    @staticmethod
    def validar_componente(componente:str, lst_componentes):
        '''Método para validar si un elemento pertenece a una lista'''
        return componente in lst_componentes
    
    def validar_pizza(self):
        '''Método que validar si una Pizza es valida'''
        es_valida = False
        
        if len(self.ingredientes) == Pizza.num_ingredientes:
            validaciones = [Pizza.validar_componente(self.ingredientes[0], ingredientes_proteicos),
                            Pizza.validar_componente(self.ingredientes[1], ingredientes_vegetales),
                            Pizza.validar_componente(self.ingredientes[2], ingredientes_vegetales),
                            Pizza.validar_componente(self.masa, masas)]
            
            es_valida = all(validaciones)
        
        return es_valida
    
    def realizar_pedido(self):
        '''Mètodo para realizar un pedido, finalmente valida si el pedido es válido'''
        print("\nRealizar pedido de pizza")
        print("========================\n")
        self.ingredientes.append(input("Ingrese ingrediente proteico: ").lower())
        self.ingredientes.append(input("Ingrese primer ingrediente vegetal: ").lower())
        self.ingredientes.append(input("Ingrese segundo ingrediente vegetal: ").lower())
        self.masa = input("Ingrese tipo de masa: ").lower()
        
        self.pizza_valida = self.validar_pizza()

if __name__ == '__main__':
    ing_true = ['pollo','tomate', 'aceitunas']
    ing_false = ['koala','tomate', 'aceitunas']
    
    # Probando constructor
    pedido1 = Pizza()
    print(pedido1.__dict__)
    pedido2 = Pizza(ing_true)
    print(pedido2.__dict__)
    pedido3 = Pizza(ing_true,'delgada')
    print(pedido3.__dict__)
    pedido3 = Pizza(ing_false,'tradicional')
    print(pedido3.__dict__)
    pedido4 = Pizza(ing_true[:-1],'delgada')
    print(pedido4.__dict__)